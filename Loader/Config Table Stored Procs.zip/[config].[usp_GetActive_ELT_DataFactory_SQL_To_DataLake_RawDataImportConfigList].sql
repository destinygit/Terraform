CREATE OR ALTER PROCEDURE [config].[usp_GetActive_ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList]
(
	@pBusiness_Area VARCHAR(255) /*e.g. MortgageOrigination, Insurance*/
	, @pLoad_Type VARCHAR(255) /*e.g. BatchDeltaLoad, BatchFullLoad*/
	, @pBatch_Execution_Tag VARCHAR(255) /*e.g. SmartApps_MicroBatch, ComCorp_DailyBatch -- Determines as part of which trigger this will run*/
)
AS
/*=====================================================================================================================================================
Author:			Dian Germishuizen (Tangent Solutions)
Description:	This procedure will return data from the base condfig table if the config record is active.
Usage			Currently being used by Data Factory to get the list of records to process. 
				Only for BatchDeltaLoad config data.
Parameters		@pBusiness_Area - used to limit the config records returned to a single business area e.g. Insurance, Mortgage Origination. 
					THis is used when the source data for the different areas are used in different Data Factory trigger scheduleds, so we need to isolate which config records are returned at run time
				@pLoad_Type
					Can be used to only get BatchDeltaLoad, BatchFullLoad or any other load types defined in future. 
-------------------------------------------------------------------------------------------------------------------------------------------------------
Changes Made:	
Date			Author					Description (What changes were made to this code on this day)
----------		------------------		---------------------------------------------------------------------------------------------------------------
2021-11-02		Dian Germishuizen		Created - retrieved base query logic from [config].[vw_Active_ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_BatchDeltaLoad]
2021-11-09		Dian Germishuizen		Added [Batch_Execution_Tag]
-------------------------------------------------------------------------------------------------------------------------------------------------------
TODO: 
--Place code to test object here

EXEC [config].[usp_GetActive_ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList] 
	@pBusiness_Area = 'Insurance'
	, @pLoad_Type = 'BatchFullLoad'
	, @pBatch_Execution_Tag = 'RavenDB_MicroBatch'
	
EXEC [config].[usp_GetActive_ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList] 
	@pBusiness_Area = 'Insurance'
	, @pLoad_Type = 'BatchDeltaLoad'
	, @pBatch_Execution_Tag = 'RavenDB_MicroBatch'

=====================================================================================================================================================*/
BEGIN

	SELECT 
		[RawDataImportConfigList].[RowNumber]
		, [RawDataImportConfigList].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
		, [RawDataImportConfigList].[Batch_Execution_Tag]
		, [RawDataImportConfigList].[Business_Area]
		, [RawDataImportConfigList].[Source_System_Type]
		, [RawDataImportConfigList].[Load_Type]
		, [RawDataImportConfigList].[Delta_Load_Source_LatestModifiedDateTime_Column]
		, [RawDataImportConfigList].[Dataset]
		, [RawDataImportConfigList].[Source_SQL_Server]
		, [RawDataImportConfigList].[Source_SQL_Database]
		, [RawDataImportConfigList].[Source_SQL_Schema]
		, [RawDataImportConfigList].[Source_SQL_Table]
		, [RawDataImportConfigList].[Target_BlobStorage_StorageAccount]
		, [RawDataImportConfigList].[Target_BlobStorage_Container]
		, [RawDataImportConfigList].[Target_BlobStorage_Directory]
		, [RawDataImportConfigList].[Target_BlobStorage_FileName]
		, [RawDataImportConfigList].[Target_BlobStorage_FileExtention]
		, [RawDataImportConfigList].[Target_BlobStorage_FileType]
		, [RawDataImportConfigList].[Target_BlobStorage_ColumnDelimitter]
		, [RawDataImportConfigList].[Archive_BlobStorage_Container]
		, [RawDataImportConfigList].[Archive_BlobStorage_Directory]
		, [RawDataImportConfigList].[Archive_MoveOrCopy]
		, [RawDataImportConfigList].[Archive_Frequency]
		, [RawDataImportConfigList].[Bronze_Layer_SQLServerlessSchemaName]
		, [RawDataImportConfigList].[Silver_Layer_SQLServerlessSchemaName]
		, [RawDataImportConfigList].[Bronze_Layer_ExternalTable_ColumnDefinition]
		, [RawDataImportConfigList].[IsActive]
		/*Delta Load Watermark columns*/
		/*NextExecution_DeltaLoad_StartDateTime
			Get the last known end date time from the delta load log. Use that as the next start date time. 
			If there is no log for this dataset as yet i.e. the returned value IS NULL, default to 00:00:00 of the current day be casting to date then back to datetime
			If it does return a value, use it as is. */
		, CAST(
			CASE
				WHEN [DeltaLoadWatermarkLog].[DeltaLoad_EndDateTime] IS NULL 
					THEN CAST(CAST(SYSUTCDATETIME() AS DATE) AS DATETIME2)
				ELSE CAST([DeltaLoadWatermarkLog].[DeltaLoad_EndDateTime] AS DATETIME2)
			END
			AS DATETIME2) AS [NextExecution_DeltaLoad_StartDateTime]
		, [DeltaLoadWatermarkLog].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
	FROM [config].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList] as [RawDataImportConfigList]
	/* Get the latest end date time of the delta load watermark table. Will use that as the new start date time */
	LEFT JOIN [config].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog] AS [DeltaLoadWatermarkLog]
		ON [DeltaLoadWatermarkLog].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID] = [RawDataImportConfigList].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
	WHERE [RawDataImportConfigList].[IsActive] = 1 /* Only acvtive records - enables you to turn of datasets from processing via config record update if needed */
		/*Limit the data based on the paramters passed in*/
		AND [RawDataImportConfigList].[Load_Type] = @pLoad_Type
		AND [RawDataImportConfigList].[Business_Area] = @pBusiness_Area
		AND [RawDataImportConfigList].[Batch_Execution_Tag] = @pBatch_Execution_Tag

END

/*Version of the next execution date time where it subtracts 10 min to ensure no records are missed
		, CAST(
			CASE
				WHEN [DeltaLoadWatermarkLog].[DeltaLoad_EndDateTime] IS NULL 
					THEN CAST(CAST(SYSUTCDATETIME() AS DATE) AS DATETIME)
				ELSE DATEADD(MINUTE, -10, CAST([DeltaLoadWatermarkLog].[DeltaLoad_EndDateTime] AS DATETIME2))
			END
			AS DATETIME2) AS [NextExecution_DeltaLoad_StartDateTime]

*/



/*======================================================================
Columns available but not used at present
======================================================================

	, [Notes]
	, [InsertDateTimeUTC]
	, [UpdateDateTimeUTC]
*/

/*======================================================================
Generic JSON one can use to test in Azure Data factory in places where the ELT COnfig Record JSON is needed
======================================================================

--HO-VSSQL-SVR01 realted
{
	"RowNumber": 4,
	"ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID": "0B5C7975-8440-433A-BA0F-FB82247F78B2",
	"Dataset": "Fact - Better Life Group Targets - Better Life On Prem Data Warehouse",
	"Source_SQL_Server": "HO-VSSQL-SVR01",
	"Source_SQL_Database": "DW_MO",
	"Source_SQL_Schema": "dbo",
	"Source_SQL_Table": "BLGTargets",
	"Target_BlobStorage_StorageAccount": "tsuatstratusstorage",
	"Target_BlobStorage_Container": "rawdata",
	"Target_BlobStorage_Directory": "SQLServer_HO-VSSQL-SVR01_DW_MO/Batch/MortgageOrigination/dbo.BLGTargets",
	"Target_BlobStorage_FileName": "N/A",
	"Target_BlobStorage_FileExtention": "parquet",
	"Target_BlobStorage_FileType": "Parquet",
	"Target_BlobStorage_ColumnDelimitter": "N/A",
	"Archive_BlobStorage_Container": "N/A",
	"Archive_BlobStorage_Directory": "N/A",
	"Archive_MoveOrCopy": "N/A",
	"Archive_Frequency": "N/A",
	"Bronze_Layer_SQLServerlessSchemaName": "bronze_HO-VSSQL-SVR01_DW_MO",
	"Silver_Layer_SQLServerlessSchemaName": "silver_HO-VSSQL-SVR01_DW_MO",
	"Bronze_Layer_ExternalTable_ColumnDefinition": "[TargetMonth] DATETIME2(7),[BusInd] VARCHAR(8000),[RegionId] INT,[Budget_IntakeVol] FLOAT,[Budget_IntakeVal] FLOAT,[Budget_GrantVol] FLOAT,[Budget_GrantVal] FLOAT,[Budget_RegistrationVol] FLOAT,[Budget_RegistrationVal] FLOAT,[Stretch_IntakeVol] FLOAT,[Stretch_IntakeVal] FLOAT,[Stretch_GrantVol] FLOAT,[Stretch_GrantVal] FLOAT,[Stretch_RegistrationVol] FLOAT,[Stretch_RegistrationVal] FLOAT,[CreateDateTimeUTC] VARCHAR(8000)",
	"IsActive": true
}

*/

