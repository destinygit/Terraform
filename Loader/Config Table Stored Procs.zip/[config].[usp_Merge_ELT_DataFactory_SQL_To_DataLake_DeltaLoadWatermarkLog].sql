CREATE OR ALTER PROCEDURE [config].[usp_Merge_ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog]
(
	  @pELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID VARCHAR(255)  /*Generated in Data Factory*/
	, @pELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID VARCHAR(255)  /*Foreign key to the config table with the details of this dataset's ELT source and target*/
    , @pDeltaLoad_StartDateTime VARCHAR(255) /*The start date time parameter that was used when this instance of the delta load was triggered*/
    , @pDeltaLoad_EndDateTime VARCHAR(255) /*The end date time parameter that was used when this instance of the delta load was triggered. This will be used as the Start Date Time on the next execution*/
	, @pDataLake_IngestionDateTimeStamp_UTC VARCHAR(8000)  /*"2020-04-01 06:25" - date and time when the pipeline was executed to import the data from source into data lake. The same for all datasets processed in same execution*/
    , @pStatus VARCHAR(8000)  /*This status will indicate whether this batch has started loading, or whether is has completed loading. */
    , @pDataFactory_CopyActivity_Input NVARCHAR(MAX)  /*This will capture the full JSON input of the copy activity that performs the data movement. This can be used to troubleshoot what caused the preceding activity to fail, if it does*/
    , @pDataFactory_CopyActivity_Output NVARCHAR(MAX)  /*This will capture the full JSON output of the copy activity that performs the data movement.  This can be used to troubleshoot what caused the preceding activity to fail, if it does*/
)
AS 
/*=====================================================================================================================================================
Author:			Dian Germishuizen (Tangent Solutions)
Description:	Procedure to update the table [config].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog]
				This is called once any time a SQL_To_DataLake dataset is processed by Data Factory using custom Delta Loading mechanisms
-------------------------------------------------------------------------------------------------------------------------------------------------------
Changes Made:	
Date			Author					Description (What changes were made to this code on this day)
----------		------------------		---------------------------------------------------------------------------------------------------------------
2021-10-26		Dian Germishuizen		Created
-------------------------------------------------------------------------------------------------------------------------------------------------------
TODO: 
--Place code to test object here
=====================================================================================================================================================*/
BEGIN
	BEGIN TRY
	        BEGIN TRANSACTION LogSQL2DLELTDeltaLoadTran

			/*======================================================================
			Merge data from paramters into target table
			======================================================================*/
			MERGE INTO [config].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog] AS [target]
			/*The source must be defined with the USING clause*/
			USING
				(
					/*The source is made up of the attribute & key columns from the source table.*/
					SELECT 
						@pELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID AS [ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
						, @pELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID AS [ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
						, @pDeltaLoad_StartDateTime AS [DeltaLoad_StartDateTime]
						, @pDeltaLoad_EndDateTime AS [DeltaLoad_EndDateTime]
						, @pDataLake_IngestionDateTimeStamp_UTC AS [DataLake_IngestionDateTimeStamp_UTC]
						, @pStatus AS [Status]
						, @pDataFactory_CopyActivity_Input AS [DataFactory_CopyActivity_Input]
						, @pDataFactory_CopyActivity_Output AS [DataFactory_CopyActivity_Output]
				) AS [source]
			ON /*Matching criteria, similar to a join's ON clause between the target table and the source table.*/
				(
					[source].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID] = [target].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
				)
			/*If the Keys's above match to the existing record but some attributes' values are different, then the record has changed;
			therefore, update the existing record in the target.
			The EXISTS & EXCEPT clauses ensure the the nullable columns are still compared when either or both are null. Normal <> operators will be inconsistent when NULLs are involved.
			This syntax performs the same effect as saying 
				(Tgt.ValueA <> Src.ValueA) OR (Tgt.ValueA IS NULL AND Src.ValueA IS NOT NULL) OR (Tgt.ValueA IS NOT NULL AND Src.ValueA IS NULL)
			for every column*/
			WHEN MATCHED AND
				(
					EXISTS
					(
						SELECT
							[target].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
							, [target].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
							, [target].[DeltaLoad_StartDateTime]
							, [target].[DeltaLoad_EndDateTime]
							, [target].[DataLake_IngestionDateTimeStamp_UTC]
							, [target].[Status]
							, [target].[DataFactory_CopyActivity_Input]
							, [target].[DataFactory_CopyActivity_Output]				
						EXCEPT
						SELECT 
							[source].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
							, [source].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
							, [source].[DeltaLoad_StartDateTime]
							, [source].[DeltaLoad_EndDateTime]
							, [source].[DataLake_IngestionDateTimeStamp_UTC]
							, [source].[Status]
							, [source].[DataFactory_CopyActivity_Input]
							, [source].[DataFactory_CopyActivity_Output]
					)
				)
				THEN UPDATE SET
					/*Apply changes to previous record version here if there are differences*/
					  [target].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID] = [source].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
					, [target].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID] = [source].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
					, [target].[DeltaLoad_StartDateTime] = [source].[DeltaLoad_StartDateTime]
					, [target].[DeltaLoad_EndDateTime] = [source].[DeltaLoad_EndDateTime]
					, [target].[DataLake_IngestionDateTimeStamp_UTC] = [source].[DataLake_IngestionDateTimeStamp_UTC]
					, [target].[Status] = [source].[Status]
					, [target].[DataFactory_CopyActivity_Input] = [source].[DataFactory_CopyActivity_Input]
					, [target].[DataFactory_CopyActivity_Output] = [source].[DataFactory_CopyActivity_Output]
					, [target].[UpdateDateTimeUTC] = SYSUTCDATETIME()
					
			/*If the ID's do not match, then the record is new;
			therefore, insert the new record into the target using the values from the source.*/
			WHEN NOT MATCHED
				THEN INSERT
					(
						[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
						, [ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
						, [DeltaLoad_StartDateTime]
						, [DeltaLoad_EndDateTime]
						, [DataLake_IngestionDateTimeStamp_UTC]
						, [Status]
						, [DataFactory_CopyActivity_Input]
						, [DataFactory_CopyActivity_Output]
						, [InsertDateTimeUTC]
						, [UpdateDateTimeUTC]
					)
					VALUES
					(
						[source].[ELT_DataFactory_SQL_To_DataLake_DeltaLoadWatermarkLog_GUID]
						, [source].[ELT_DataFactory_SQL_To_DataLake_RawDataImportConfigList_GUID]
						, [source].[DeltaLoad_StartDateTime]
						, [source].[DeltaLoad_EndDateTime]
						, [source].[DataLake_IngestionDateTimeStamp_UTC]
						, [source].[Status]
						, [source].[DataFactory_CopyActivity_Input]
						, [source].[DataFactory_CopyActivity_Output]
						, SYSUTCDATETIME() /* AS InsertDateTimeUTC*/
						, NULL /* AS UpdateDateTimeUTC*/
					);

        COMMIT TRANSACTION LogSQL2DLELTDeltaLoadTran

	END TRY
	BEGIN CATCH
        IF EXISTS (SELECT 1 FROM [sys].[dm_tran_active_transactions] WHERE [name] = 'LogSQL2DLELTDeltaLoadTran')
        BEGIN
            ROLLBACK TRANSACTION LogSQL2DLELTDeltaLoadTran
        END;
    
        /*Rethrow the error to the calling code*/
        THROW;
    
	END CATCH

END